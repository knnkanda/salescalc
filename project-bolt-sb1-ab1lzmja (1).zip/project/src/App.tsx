import React, { useState } from 'react';
import { Calculator } from 'lucide-react';

function App() {
  const [unitPrice, setUnitPrice] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(0);
  const [variableCosts, setVariableCosts] = useState<number>(0);
  const [fixedCosts, setFixedCosts] = useState<number>(0);
  const [initialInvestment, setInitialInvestment] = useState<number>(0);
  
  // Calculated values
  const dailySales = unitPrice * quantity;
  const monthlySales = dailySales * 30;
  const yearlySales = dailySales * 365;
  
  // Gross profit calculation (売上総利益)
  const monthlyGrossProfit = monthlySales - variableCosts;
  const grossProfitMargin = monthlySales > 0 ? (monthlyGrossProfit / monthlySales) * 100 : 0;
  
  // Operating profit calculation
  const monthlyOperatingProfit = monthlySales - variableCosts - fixedCosts;
  const yearlyOperatingProfit = monthlyOperatingProfit * 12;
  
  // Calculate operating profit margin
  const operatingProfitMargin = monthlySales > 0 ? (monthlyOperatingProfit / monthlySales) * 100 : 0;
  
  // Calculate payback period (in months) based on operating profit
  const paybackPeriod = monthlyOperatingProfit > 0 ? initialInvestment / monthlyOperatingProfit : 0;

  // Function to convert full-width numbers to half-width
  const convertToHalfWidth = (str: string): string => {
    return str.replace(/[０-９]/g, (s) => String.fromCharCode(s.charCodeAt(0) - 0xFEE0));
  };

  // Function to handle number input with full-width support and comma separation
  const handleNumberInput = (value: string, setter: (num: number) => void) => {
    const halfWidth = convertToHalfWidth(value);
    // Remove commas before converting to number
    const numStr = halfWidth.replace(/,/g, '');
    const num = numStr === '' ? 0 : Number(numStr);
    if (!isNaN(num)) {
      setter(num);
    }
  };

  // Function to convert to 10,000 yen units
  const convertToTenThousand = (currentValue: number, setter: (num: number) => void) => {
    setter(currentValue * 10000);
  };

  // Function to convert input to percentage of daily sales
  const convertToPercentage = (currentValue: number) => {
    if (dailySales > 0) {
      const percentage = currentValue / 100;
      setVariableCosts(dailySales * 30 * percentage);
    }
  };

  // Function to format number with commas
  const formatWithCommas = (num: number): string => {
    return num ? num.toLocaleString() : '';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-rose-50 p-6">
      <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-lg p-8">
        <div className="flex items-center gap-3 mb-8">
          <Calculator className="w-8 h-8 text-pink-600" />
          <h1 className="text-2xl font-bold text-gray-800">KNN年商電卓</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                単価 (円)
              </label>
              <input
                type="text"
                value={formatWithCommas(unitPrice)}
                onChange={(e) => handleNumberInput(e.target.value, setUnitPrice)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                数量 (個/日)
              </label>
              <input
                type="text"
                value={formatWithCommas(quantity)}
                onChange={(e) => handleNumberInput(e.target.value, setQuantity)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                変動費（月）
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={formatWithCommas(variableCosts)}
                  onChange={(e) => handleNumberInput(e.target.value, setVariableCosts)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
                />
                <button
                  onClick={() => convertToTenThousand(variableCosts || 1, setVariableCosts)}
                  className="px-3 py-2 bg-pink-100 text-pink-700 rounded-md hover:bg-pink-200 transition-colors"
                >
                  万円
                </button>
                <button
                  onClick={() => convertToPercentage(variableCosts || 0)}
                  className="px-3 py-2 bg-pink-100 text-pink-700 rounded-md hover:bg-pink-200 transition-colors"
                >
                  %
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                固定費（月）
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={formatWithCommas(fixedCosts)}
                  onChange={(e) => handleNumberInput(e.target.value, setFixedCosts)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
                />
                <button
                  onClick={() => convertToTenThousand(fixedCosts || 1, setFixedCosts)}
                  className="px-3 py-2 bg-pink-100 text-pink-700 rounded-md hover:bg-pink-200 transition-colors"
                >
                  万円
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                初期投資額
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={formatWithCommas(initialInvestment)}
                  onChange={(e) => handleNumberInput(e.target.value, setInitialInvestment)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
                />
                <button
                  onClick={() => convertToTenThousand(initialInvestment || 1, setInitialInvestment)}
                  className="px-3 py-2 bg-pink-100 text-pink-700 rounded-md hover:bg-pink-200 transition-colors"
                >
                  万円
                </button>
              </div>
            </div>
          </div>

          <div className="bg-pink-50 p-6 rounded-lg space-y-4">
            <div>
              <h3 className="text-sm font-medium text-gray-500">売上予測</h3>
              <div className="mt-2 space-y-2">
                <p className="text-lg">
                  日商: <span className="font-bold text-pink-600">{dailySales.toLocaleString()}円</span>
                </p>
                <p className="text-lg">
                  月商: <span className="font-bold text-pink-600">{monthlySales.toLocaleString()}円</span>
                </p>
                <p className="text-lg">
                  年商: <span className="font-bold text-pink-600">{yearlySales.toLocaleString()}円</span>
                </p>
              </div>
            </div>

            <div className="border-t border-pink-200 pt-4">
              <h3 className="text-sm font-medium text-gray-500">収益分析</h3>
              <div className="mt-2 space-y-2">
                <p className="text-lg">
                  売上総利益（月）: <span className="font-bold text-pink-600">{monthlyGrossProfit.toLocaleString()}円</span>
                  <span className="ml-2 text-sm text-gray-600">({grossProfitMargin.toFixed(1)}%)</span>
                </p>
                <p className="text-lg">
                  営業利益（月）: <span className="font-bold text-pink-600">{monthlyOperatingProfit.toLocaleString()}円</span>
                </p>
                <p className="text-lg">
                  営業利益（年）: <span className="font-bold text-pink-600">{yearlyOperatingProfit.toLocaleString()}円</span>
                </p>
                <p className="text-lg">
                  営業利益率: <span className="font-bold text-pink-600">{operatingProfitMargin.toFixed(1)}%</span>
                </p>
                {monthlyOperatingProfit > 0 && (
                  <p className="text-lg">
                    回収期間: <span className="font-bold text-pink-600">{paybackPeriod.toFixed(1)}ヶ月</span>
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;